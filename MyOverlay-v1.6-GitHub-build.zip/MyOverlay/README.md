# My Overlay v1.6

Android overlay app project.

- applicationId: `com.kaewkung.myoverlay`
- versionName: `1.6`
- versionCode: `9`

## Build on GitHub Actions
1. Upload this project ZIP to the repository root.
2. Keep `.github/workflows/build-apk.yml` from this project (replace the old workflow).
3. Run **Build My Overlay APK v1.6** from Actions.
4. Download artifact **MyOverlay-v1.6-apk**.

The workflow prefers the project ZIP with the highest `versionCode`, then verifies the generated APK metadata before uploading it.
