package com.kaewkung.myoverlay

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

const val MAX_LAYERS = 6

enum class Kind { WEB, IMAGE, TEXT }

/** ตำแหน่ง/ขนาดแบบสัดส่วนของหน้าจอ (0..1) เพื่อใช้ได้กับทุกความละเอียด */
class Box(var x: Float, var y: Float, var w: Float, var h: Float) {
    fun toJson(): JSONObject = JSONObject()
        .put("x", x.toDouble()).put("y", y.toDouble())
        .put("w", w.toDouble()).put("h", h.toDouble())

    companion object {
        fun from(o: JSONObject?, d: Box): Box =
            if (o == null) Box(d.x, d.y, d.w, d.h) else Box(
                o.optDouble("x", d.x.toDouble()).toFloat(),
                o.optDouble("y", d.y.toDouble()).toFloat(),
                o.optDouble("w", d.w.toDouble()).toFloat(),
                o.optDouble("h", d.h.toDouble()).toFloat()
            )
    }
}

class Layer(
    val id: String = UUID.randomUUID().toString(),
    var kind: Kind,
    var name: String,
    var enabled: Boolean = true,
    var url: String = "",
    var text: String = "",
    var textSize: Int = 28,
    var textColor: String = "#FFFFFF",
    var uri: String = "",
    var opacity: Int = 100,
    var portrait: Box = Box(0.05f, 0.10f, 0.60f, 0.25f),
    var landscape: Box = Box(0.05f, 0.10f, 0.35f, 0.40f)
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("kind", kind.name).put("name", name).put("enabled", enabled)
        .put("url", url).put("text", text).put("textSize", textSize)
        .put("textColor", textColor).put("uri", uri).put("opacity", opacity)
        .put("portrait", portrait.toJson()).put("landscape", landscape.toJson())

    companion object {
        fun fromJson(o: JSONObject): Layer? {
            val kind = try {
                Kind.valueOf(o.optString("kind"))
            } catch (e: Exception) {
                return null
            }
            val d = newLayer(kind, "")
            return Layer(
                id = o.optString("id").ifEmpty { UUID.randomUUID().toString() },
                kind = kind,
                name = o.optString("name", "เลเยอร์"),
                enabled = o.optBoolean("enabled", true),
                url = o.optString("url", ""),
                text = o.optString("text", ""),
                textSize = o.optInt("textSize", 28),
                textColor = o.optString("textColor", "#FFFFFF"),
                uri = o.optString("uri", ""),
                opacity = o.optInt("opacity", 100).coerceIn(10, 100),
                portrait = Box.from(o.optJSONObject("portrait"), d.portrait),
                landscape = Box.from(o.optJSONObject("landscape"), d.landscape)
            )
        }
    }
}

/** สร้างเลเยอร์ใหม่พร้อมตำแหน่งเริ่มต้นที่เหมาะกับชนิด */
fun newLayer(kind: Kind, name: String): Layer {
    val l = Layer(kind = kind, name = name)
    when (kind) {
        Kind.WEB -> {
            l.portrait = Box(0.05f, 0.12f, 0.60f, 0.28f)
            l.landscape = Box(0.05f, 0.12f, 0.35f, 0.45f)
        }
        Kind.IMAGE -> {
            l.portrait = Box(0.55f, 0.10f, 0.35f, 0.20f)
            l.landscape = Box(0.70f, 0.10f, 0.20f, 0.30f)
        }
        Kind.TEXT -> {
            l.portrait = Box(0.10f, 0.45f, 0.80f, 0.12f)
            l.landscape = Box(0.20f, 0.40f, 0.60f, 0.18f)
        }
    }
    return l
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("my_overlay", Context.MODE_PRIVATE)

    fun load(c: Context): MutableList<Layer> {
        val out = mutableListOf<Layer>()
        try {
            val a = JSONArray(prefs(c).getString("layers_v1", "[]") ?: "[]")
            for (i in 0 until a.length()) {
                Layer.fromJson(a.getJSONObject(i))?.let { out.add(it) }
            }
        } catch (e: Exception) {
            // ข้อมูลเสีย: เริ่มใหม่
        }
        return out
    }

    /** ความทึบรวมของ Overlay ทั้งหมด 10–100% (ค่าเริ่มต้น 100 = ทึบเต็มที่) */
    fun master(c: Context): Int = prefs(c).getInt("master_opacity", 100).coerceIn(10, 100)

    fun setMaster(c: Context, v: Int) {
        prefs(c).edit().putInt("master_opacity", v.coerceIn(10, 100)).apply()
    }

    fun save(c: Context, list: List<Layer>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        prefs(c).edit().putString("layers_v1", a.toString()).apply()
    }
}
